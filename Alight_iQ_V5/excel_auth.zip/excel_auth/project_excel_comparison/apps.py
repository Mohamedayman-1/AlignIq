from django.apps import AppConfig


class ProjectExcelComparisonConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'project_excel_comparison'
